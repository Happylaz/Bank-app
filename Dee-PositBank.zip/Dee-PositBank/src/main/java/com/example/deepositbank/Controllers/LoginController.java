package com.example.deepositbank.Controllers;


import com.example.deepositbank.Models.Model;
import com.example.deepositbank.Views.AccountType;
import javafx.collections.FXCollections;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;


public class LoginController implements Initializable {
    public ChoiceBox<AccountType> account_selector;
    public Label bank_account_number_lbl;
    public TextField bank_account_number_fld;
    public TextField password_fld;
    public Button login_btn;
    public Label error_lbl;
    public Label password_lbl;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        account_selector.setItems(FXCollections.observableArrayList(AccountType.CUSTOMER,AccountType.ACCOUNT_MANAGER));
        account_selector.setValue(Model.getInstance().getViewFactory().getLoginAccountType());
        account_selector.valueProperty().addListener(observable -> Model.getInstance().getViewFactory().setLoginAccountType(account_selector.getValue()));
        login_btn.setOnAction(event -> onLogin());

    }

    private  void onLogin() {
        Stage stage = (Stage) error_lbl.getScene().getWindow();
        Model.getInstance().getViewFactory().closeStage(stage);
       if (Model.getInstance().getViewFactory().getLoginAccountType() == AccountType.CUSTOMER){
           Model.getInstance().getViewFactory().showCustomerWindow();
       }else {
           Model.getInstance().getViewFactory().showAccountManagerWindow();
       }


    }
}
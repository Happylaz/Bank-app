package com.example.deepositbank.Models;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.time.LocalDate;


public class Customer {
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty accountNumber;

    private final StringProperty sortCode;

    private final ObjectProperty<Account> currentAccount;

    private final ObjectProperty<Account> savingsAccount;

    private final ObjectProperty<Account> rewardAccount;

    private final ObjectProperty<Account> basicAccount;

    private final ObjectProperty<Account> isaAccount;

    private final ObjectProperty<LocalDate> dateCreated;


    public Customer(String fName, String lName, String aNumber, String sCode, Account cAccount, Account sAccount, Account rAccount, Account bAccount, Account isaAccount, LocalDate date) {
        this.firstName = new SimpleStringProperty(this, "FirstName", fName);
        this.lastName = new SimpleStringProperty(this, "LastName", lName);
        this.accountNumber = new SimpleStringProperty(this, "Account Number", aNumber);
        this.sortCode = new SimpleStringProperty(this, "Sort Code", sCode);
        this.currentAccount = new SimpleObjectProperty<>(this, "Current Account", cAccount);
        this.savingsAccount = new SimpleObjectProperty<>(this, "Savings Account", sAccount);
        this.rewardAccount = new SimpleObjectProperty<>(this, "Reward Account", rAccount);
        this.basicAccount = new SimpleObjectProperty<>(this, "Basic Account", bAccount);
        this.isaAccount = new SimpleObjectProperty<>(this, "Isa Account", isaAccount);
        this.dateCreated = new SimpleObjectProperty<>(this, "Date", date);
    }

    public StringProperty firstNameProperty() {
        return firstName;
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public StringProperty aNumberProperty() {
        return accountNumber;
    }

    public StringProperty sCodeProperty() {
        return sortCode;
    }

    public ObjectProperty<Account> currentAccountProperty() {
        return currentAccount;
    }

    public ObjectProperty<Account> savingsAccountProperty() {
        return savingsAccount;
    }

    public ObjectProperty<Account> rewardAccountProperty() {
        return rewardAccount;
    }

    public ObjectProperty<Account> basicAccountProperty() {
        return basicAccount;
    }

    public ObjectProperty<Account> isaAccountProperty() {
        return isaAccount;
    }

    public ObjectProperty<LocalDate> dateProperty() {
        return dateCreated;
    }
}







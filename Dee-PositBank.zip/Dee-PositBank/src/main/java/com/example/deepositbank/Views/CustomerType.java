package com.example.deepositbank.Views;

public enum CustomerType {

    INDIVIDUAL,

    BUSINESS,

    CHARITY

}

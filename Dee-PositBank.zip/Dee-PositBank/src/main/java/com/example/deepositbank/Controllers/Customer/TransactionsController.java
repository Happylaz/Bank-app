package com.example.deepositbank.Controllers.Customer;

import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

import java.net.URL;
import java.util.ResourceBundle;

public class TransactionsController implements Initializable {

    public ListView transactions_listview;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

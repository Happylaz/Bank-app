package com.example.deepositbank.Models;

public class RewardAccount {
}

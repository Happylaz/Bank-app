package com.example.deepositbank.Controllers.Customer;

import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {
    public Text user_name;
    public Label login_date;
    public Label current_bal;
    public Label current_acc_num;
    public Label savings_bal;
    public Label savings_acc_num;
    public Label income_lbl;
    public Label expense_lbl;
    public ListView transaction_listview;
    public TextField bank_acc_fld;
    public TextField amount_fld;
    public TextArea message_fld;
    public Button Send_money_btn;
    public TextField sort_code_fld;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {}


}

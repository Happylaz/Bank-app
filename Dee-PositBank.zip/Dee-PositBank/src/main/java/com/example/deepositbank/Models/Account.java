package com.example.deepositbank.Models;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public abstract class Account {

    private final StringProperty accountNumber;

   private final StringProperty sortCode;

    private final DoubleProperty balance;

    public Account(String accountNumber, String sortCode, double balance){
        this.accountNumber = new SimpleStringProperty(this,"Account Number", accountNumber);
        this.sortCode = new SimpleStringProperty(this,"Sort Code", sortCode );
        this.balance = new SimpleDoubleProperty(this,"Balance", balance);
    }

    public StringProperty accountNumberProperty() {return accountNumber;}

    public StringProperty sortCodeProperty() {return sortCode;}

    public DoubleProperty balanceProperty() {return balance;}



}

package com.example.deepositbank.Controllers.AccountManager;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class DepositController implements Initializable {

    public TextField aNumber_fld;
    public Button search_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

package com.example.deepositbank.Models;

import com.example.deepositbank.Views.ViewFactory;

public class Model {
    private static Model model; // Declaring the 'model' variable
    private final ViewFactory viewFactory;

    private Model(){
        this.viewFactory = new ViewFactory();
    }

    public static synchronized Model getInstance() {
        if (model == null) {
            model = new Model(); // Create a new instance if 'model' is null
        }
        return model;
    }

    public ViewFactory getViewFactory() {
        return viewFactory;
    }
}

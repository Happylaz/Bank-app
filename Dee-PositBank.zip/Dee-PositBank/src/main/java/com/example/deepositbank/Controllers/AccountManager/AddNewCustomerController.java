package com.example.deepositbank.Controllers.AccountManager;

import com.example.deepositbank.Views.BankAccountType;
import com.example.deepositbank.Views.CustomerType;
import javafx.collections.FXCollections;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

public class AddNewCustomerController implements Initializable {

    public ChoiceBox<CustomerType> customer_selector;
    public TextField fName_fld;
    public TextField lName_fld;
    public TextField address_fld;
    public PasswordField password_fld;
    public ChoiceBox<BankAccountType> bank_acc_selector;
    public CheckBox aNumber_box;
    public Label aNumber_lbl;
    public CheckBox sort_code_box;
    public Label sc_lbl;
    public TextField ch_amount_fld;
    public Button add_customer_btn;
    public Label error_lbl;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        customer_selector.setItems(FXCollections.observableArrayList(CustomerType.INDIVIDUAL,CustomerType.BUSINESS,CustomerType.CHARITY));

        bank_acc_selector.setItems(FXCollections.observableArrayList(BankAccountType.REWARD_ACCOUNT,BankAccountType.BASIC_ACCOUNT,BankAccountType.ISA_ACCOUNT));

    }



}
